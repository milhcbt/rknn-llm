from rkllm.api.rkllm_base import RKLLMBase

class RKLLM:
    def __init__(self, v=''):
        self.base = RKLLMBase(v)

    def load_huggingface(self, model, model_lora=None, device='cpu', dtype='float32', custom_config=None, load_weight=True):
        """
        Load huggingface model
        :param model: base model path
        :param model_lora: lora model path
        :param device: cuda or cpu
        :param dtype: the dtype required to run the model, options: float16,bfloat16,float32
        :param custom_config: config of custom model
        :param load_weight: when load_weight is set to False, no weight is loaded for testing model conversion
        :return: success: 0, failure: -1
        """
        ret = self.base.load_huggingface(model, model_lora, device, dtype, custom_config, load_weight)
        return ret

    def load_gguf(self, model):
        """
        Load gguf model
        :param model_path: gguf model path
        :return: success: 0, failure: -1
        """
        ret = self.base.load_gguf(model)
        return ret

    def update_rkllm(self, model):
        """
        Update rkllm model
        :param model_path: rkllm model path
        :return: success: 0, failure: -1
        """
        ret = self.base.update_rkllm(model)
        return ret

    def build(self, do_quantization=True, optimization_level=1, quantized_dtype='w8a8', quantized_algorithm='normal', target_platform='rk3588', num_npu_core=3, extra_qparams=None, dataset=None, hybrid_rate=0, max_context=4096):
        """
        Build model
        :param do_quantization: Need do quantization
        :param optimization_level: 0 means speed and memory are prioritized, while 1 means accuracy is prioritized
        :param quantized_dtype: quantization type, options: [w4a16, w4a16_g32, w4a16_g64, w4a16_g128, w8a8, w8a8_g128, w8a8_g256, w8a8_g512]
        :param quantized_algorithm: quantization algorithm, options: [none, normal, normal_r1~normal_r64, grq, grq_r1~grq_r64], grq/grq_r*/grq_r* only supports 4bit quantization
        :param target_platform: platform type, options: [rk3588, rk3576, rk3562, rv1126b, cuda], cuda is mainly for Jetson Orin Nano platform and only supports w4a16_g32 quantization type
        :param num_npu_core: number of npu core required, options: rk3588 is [1,2,3], rk3576 is [1,2], rk3562 is [1], rv1126b is [1]
        :param extra_qparams: user-provided quantization parameters or the quantization parameters cached by grq quantized_algorithm[grq.qparams]
        :param dataset: the path to the dataset for calibration: 
            1、when the input is text, generate a json file following this structure: [{"input":"", "target": ""},...]
            2、when the input is inputs_embeds, generate the specified format according to the official demo script.
        :param hybrid_rate: block(group-wise quantization) ratio, whose value is between 0 and 1, 0 indicating the disable of mixed quantization
        :param max_context: required max context limit value, which must not exceed 16,384 (16K tokens) and must be a multiple of 32 (e.g., 32, 64, 96, ..., 16,384)
        :return: success: 0, failure: -1
        """
        ret = self.base.build(do_quantization, optimization_level, quantized_dtype, quantized_algorithm, target_platform, num_npu_core, extra_qparams, dataset, hybrid_rate, max_context)
        return ret

    def export_rkllm(self, export_path, export_tokenizer=True, export_embedding=True):
        """
        Export rknn model to file
        :param export_path: Export rkllm model path
        :param export_tokenizer: whether to export tokenizer vocabulary
        :param export_embedding: whether to export embedding tensor
        :return: success: 0, failure: -1
        """
        ret = self.base.export_rkllm(export_path, export_tokenizer, export_embedding)
        return ret

    def eval_accuracy(self, apply_chat_template=False, wiki_test=True, mmlu_test=False, cmmlu_test=False, humaneval_test=False, gsm8k_test=False):
        """
        Evaluate model accuracy
        :param seqlen: the length of input
        :param dataset: the name of dataset
        :return: success: 0, failure: -1
        """
        ret = self.base.eval_accuracy(apply_chat_template, wiki_test, mmlu_test, cmmlu_test, humaneval_test, gsm8k_test)
        return ret

    def chat_model(self, messages, args, stream=False):
        """
        Return text
        :param messages: input text, the text needs to add prompt words
        :param args: inference configuration parameters, such as top-k and other sampling strategy parameters
        :param stream: Whether to use streaming output
        :return: 
            - If `stream=True`, returns a generator object that yields text chunks incrementally.
            - If `stream=False`, returns the complete generated text as a string.
            - In case of failure, returns None.
        """
        return self.base.chat_model(messages, args, stream)

    def get_logits(self, inputs):
        """
        Return logits
        :param inputs: {"input_ids":"",}, just like the method of calling models in huggingface
        :return: success: logits, failure: None
        """
        ret = self.base.get_logits(inputs)
        return ret